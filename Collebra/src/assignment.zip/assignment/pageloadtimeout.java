package assignment;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;

public class pageloadtimeout {
private static File screenshot;

public static void main(String[] args) {
	System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver_win32/chromedriver.exe");
	ChromeDriver driver =new ChromeDriver();
	driver.get("https://www.zomato.com/");
	driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	driver.manage().timeouts().pageLoadTimeout(3,TimeUnit.SECONDS );
	screenshot=driver.getScreenshotAs(OutputType.FILE);
	System.out.println("screenshot");
 File Destfile = new File("./errorshots/webpage.png");
 screenshot.renameTo(Destfile);
	
	
	
	
	
}
}
