package assignment;

import org.openqa.selenium.chrome.ChromeDriver;

public class findtheelementusingpariallink {
public static void main(String[] args) {
	System.setProperty("webdriver,chrome.driver","./drivers/chromedriver_win32/chro,driver.exe");
	ChromeDriver driver=new ChromeDriver();
	driver.get(");
}
}
